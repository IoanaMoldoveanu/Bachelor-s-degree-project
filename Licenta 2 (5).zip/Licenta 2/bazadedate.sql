CREATE DATABASE studio_beauty;
USE studio_beauty;
CREATE TABLE programari (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nume VARCHAR(255) NOT NULL,
    prenume VARCHAR(255) NOT NULL,
    data_preferinta DATE NOT NULL,
    ora_preferinta TIME NOT NULL,
    -- servicii VARCHAR(255),
--     stilist_preferat VARCHAR(255),
    telefon VARCHAR(20),
    mail VARCHAR(255)
);
SHOW TABLES;
select * from programari;
INSERT INTO programari (nume, prenume, data_preferinta, ora_preferinta, telefon, mail)
VALUES ('NumeClient', 'PrenumeClient', '2023-10-10', '14:00:00', 'Serviciu1, Serviciu2', 'StilistPreferat', 'TelefonClient', 'EmailClient');

