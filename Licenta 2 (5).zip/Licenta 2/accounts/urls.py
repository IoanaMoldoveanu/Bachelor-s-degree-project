# C:\Users\user\OneDrive\Documente\Licenta\accounts\urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('profile/', views.profile_view, name='profile_view'),
    path('accounts/', views.accounts_view, name='accounts_view'),
    path('register/', views.register_view, name='register'),
    path('', views.home, name='home'),
    path('contact/', views.contact, name='contact'),
    path('prices/', views.prices, name='prices'),
    path('appm/', views.appm, name='appm'),
    path('appf/', views.appf, name='appf'),
    path('app/', views.app, name='app'),
    path('end/', views.end, name='end'),
    path('offers/', views.offers, name='offers'),
    path('profile/', views.profile, name='profile'),
    path('logout/', views.logout_view, name='logout'),
    path('employee/', views.employee, name='employee'),
]


